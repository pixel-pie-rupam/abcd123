export { default } from './CourseDetail';

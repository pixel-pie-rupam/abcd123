export { default } from './CourseDetail';
